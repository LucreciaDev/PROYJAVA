package alfonso_galiano;

import java.util.LinkedList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * JN: Observaciones:
 *     - Agregar el uso de otra estructura para facilitar el acceso a todos los estantes de una categoria dada y modificar el codigo para utilizarla
 *     - Dividir la logica pasando m�s responsabilidades a la clase Estante.
 *     - Corregir  
 *     - hacer mas bonito el toString. Esto implicar� modificar el toString de todas las clases.
 * 
 */
public class BDUNGS {
	private String nombre;
	private LinkedList <Estante> estantes;
	
	public BDUNGS(int cantEstantes, double tamanio) {
		// TODO Auto-generated constructor stub
		this.nombre="";//No es informacion relevante para los ejercicios, pero se supone por logica que debe existir
		               // JN: Cual l�gica!? Si no se pide y no se usa, no deber�a existir! Principio YAGNI (no vas a necesitarlo).
		this.estantes= new LinkedList <Estante>();
		for(int i=0;i<cantEstantes;i++){
			// JN: Popdr�as modificar el constructor para crear estantes sin rotulo directamente. 
			// De este modo, siempre controlaras el valor de la categoria dentro de la clase Estante.
			Estante nuevo= new Estante(null,tamanio);
			this.estantes.add(nuevo);
			
		}
	}

	// JN: No est�s verificando si el estante esta vaci� antes de rotularlo.
	//     Ademas, las verificaciones internas del estado del estante las deber�a hacer el estante y NO BDUNGS.
	//     Por ejemplo, BDUNGS valida que el numero de orden sea valido y obtiene el est�nte. luego le pasa la responsabilidad al estante.
	//     Internamente el estante hace sus propias validaciones y se actualiza o genera una excepcion!
	public void rotularEstante(String categoria, int i) {
		if (estantes.get(i).getEstaRotulado()==false) {
			estantes.get(i).setRotulo(categoria);//le modifica el rotulo
			estantes.get(i).setEstaRotulado(true);
		}
		else {
			throw new RuntimeException("No es posible rotular este estante");
		}
	}

	public boolean ingresarLibro(String isbn, String cat, String titulo, int ancho) {
		if(existeCategoria(cat)) {
			for (int i=0; i<estantes.size();i++) {
				if (estantes.get(i).getRotulo()==cat) {
					if(estantes.get(i).getEspacioLibre()>=ancho) {
						estantes.get(i).guardarLibro(isbn, cat, titulo, ancho);
						return true;
					}	
				}
			}
		}
		else {
			throw new RuntimeException("No existe ningun estante con dicha categoria");
		}
		return false;
		
	}


	public double espacioLibre(int i) {
		if (estantes.get(i).getEstaRotulado())
			return estantes.get(i).getEspacioLibre();
		else
			throw new RuntimeException("No esta rotulado");
	}
	
	
	/**
	 * JN: Esta mal la actualizacion en el replace. el '+1' tiene que estar fuera de librosDeCategoria.get()
	 *     Los libros se crean dentro del estante pero la biblioteca tambien sabe tratarlos!
	 *     No se est� delegando correctamente la funcion del conteo dentro del estante.
	 */
	public HashMap<String, Integer> verLibrosCategoria(String categoria) {
		HashMap<String,Integer> librosDeCategoria = new HashMap<String,Integer>();
		if(!existeCategoria(categoria)) {
			throw new RuntimeException("No se encuentra dicha categoria");
		}
		for (Estante est: this.estantes) {
			if (est.getRotulo()==categoria) {
				for (Libro libro : est.getEstante()) {
					if (!librosDeCategoria.containsKey(libro.obtenerISBN())) {
						librosDeCategoria.put(libro.obtenerISBN(), 1);
					}
					else {
						librosDeCategoria.replace(libro.obtenerISBN(), librosDeCategoria.get(libro.obtenerISBN() + 1));
					}
				}
			}
		}
		return librosDeCategoria;
	}

	/**
	 * JN: El casteo de it.next() est� de m�s! Se especific� que era un Estante al crear la variable Iterator<Estante> 
	 * 
	 */
	public void eliminarLibro(String isbn) {
		Iterator<Estante> it=estantes.iterator();
		while (it.hasNext()) {
			Estante est = (Estante) it.next();
			est.eliminarLibro(isbn);
		}
		
	}
	

	/**
	 * JN: El Estante al tener los metodos setRotulo y setEstaRotulado puede facilmente corromperse su estado interno!
	 *     Adem�s de que uno es consecuencia directa del otro.
	 *     Como pueden ver, tambien se hace mas engorroso el codigo.
	 *     
	 *     El reacomodar debe distribuir os libros del estante (no vacio) mas vacio entre los dem�s estantes con libros.
	 *     y si puede vaciar el estante, repetir la operacion.
	 *     Al final, la cantidad de repeticiones ser� la cantidad de estantes liberados.
	 *     Nunca se pide que se le quite el rotulo a los estantes que fueron vaciados.
	 * 
	 */
	public int reacomodarCategoria(String categoria) {
		int cont=0;
		if(!existeCategoria(categoria)) {
			throw new RuntimeException("No se encuentra dicha categoria");
		}
		else {
			for (Estante est: this.estantes) {
				if (est.getRotulo()==categoria) {
					reacomodarLibros(est,estanteConMasEspacio(categoria));
				}
			}
			if (estanteConMasEspacio(categoria).estaVacio()) {
				estanteConMasEspacio(categoria).setRotulo(null);
				estanteConMasEspacio(categoria).setEstaRotulado(false);
				cont++;
			}
		}
		return cont;
	}

	// JN: Si se usa una estructura auxiliar para obtener todos los estantes de una categoria dada, esto se resuelve mas facil.
	private boolean existeCategoria(String categoria) {
		boolean ret=false;
		for (Estante est: this.estantes) {
			ret = ret || est.getRotulo()==categoria;
		}
		return ret;
	}

	/**
	 * JN: Nunca se verifica que el estante 0 sea de la categoria deseada!
	 *     Esto puede retornar un estante de otra categoria a la solicitada.
	 *     CORREGIRLO
	 */
	private Estante estanteConMasEspacio(String cat) {
		Estante vacio = estantes.get(0);
		for (Estante est: this.estantes) {
			if (est.getRotulo()==cat && est.getEspacioLibre()>vacio.getEspacioLibre()) {
				vacio=est;
			}
		}
		return vacio;
	}
	
	/**
	 * JN: Se pasa un ejemplar pero se borran todos del estante de origen!
	 *     Se este antregando un atributo interno de la clase estante si control alguno!
	 */
	private void reacomodarLibros(Estante e1, Estante e2) {
		Iterator<Libro> it=e2.getEstante().iterator();
		while (it.hasNext()) {
			Libro l = (Libro) it.next();
			if (l.getAncho()<=e1.getEspacioLibre()) {
				e1.guardarLibro(l.obtenerISBN(), l.getCategoria(), l.getTitulo(), l.getAncho());;
				e2.eliminarLibro(l.obtenerISBN());
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder s=new StringBuilder();
		s.append("Biblioteca Digital, posee los siguientes estantes: \n");
		for(Estante est: this.estantes) {
			if (est.getEstaRotulado()) {
				s.append(est + "\n");
			}
		}
		return s.toString();
	}
	
	
}
